document.getElementById("register").addEventListener("click", () => {
  const firstName = document.getElementById("firstName").value.trim();
  const lastName = document.getElementById("lastName").value.trim();
  const email = document.getElementById("email").value.trim();
  const phone = document.getElementById("phone").value.trim();
  const gr = document.getElementById("gr").value.trim();
  const gender = document.getElementById("gender").value;
  const age = document.getElementById("age").value.trim();
  const password = document.getElementById("password").value;
  const confirmPassword = document.getElementById("password1").value;
  const message = document.getElementById("signupmessage");

  // Reset message
  message.style.display = "none";
  message.className = "messagedev";
  message.textContent = "";

  // ✅ Validation checks
  if (!firstName || !lastName || !email || !phone || !gender || !age || !password || !confirmPassword) {
    showMessage("⚠️ Please fill all required fields!", "error");
    return;
  }

  // ✅ Phone number check (only digits, 10-15 length)
  if (!/^\d{10,15}$/.test(phone)) {
    showMessage("📱 Enter a valid phone number!", "error");
    return;
  }

  // ✅ Email check
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(email)) {
    showMessage("📧 Enter a valid email address!", "error");
    return;
  }

  // ✅ Age check
  if (isNaN(age) || age < 10 || age > 100) {
    showMessage("🎂 Age must be between 10 and 100!", "error");
    return;
  }

  // ✅ Password length check
  if (password.length < 6) {
    showMessage("🔑 Password must be at least 6 characters!", "error");
    return;
  }

  // ✅ Password match check
  if (password !== confirmPassword) {
    showMessage("❌ Passwords do not match!", "error");
    return;
  }

  // ✅ Already registered check
  let users = JSON.parse(localStorage.getItem("users")) || [];
  if (users.find(u => u.email === email)) {
    showMessage("⚠️ Email already registered!", "error");
    return;
  }

  // ✅ Save user
  users.push({ firstName, lastName, email, phone, gr, gender, age, password });
  localStorage.setItem("users", JSON.stringify(users));

  showMessage("✅ Registered successfully!", "success");

  setTimeout(() => window.location.href = "login.html", 1500);

  // ✅ Helper function
  function showMessage(text, type) {
    message.textContent = text;
    message.className = `messagedev ${type}`;
    message.style.display = "block";
  }
});
