  /* Particles config */
    particlesJS("particles-js", {
      particles: {
        number: { value: 80 },
        color: { value: "#00d1ff" },
        shape: { type: "circle" },
        opacity: { value: 0.5 },
        size: { value: 3 },
        move: { enable: true, speed: 1.5 }
      }
    });