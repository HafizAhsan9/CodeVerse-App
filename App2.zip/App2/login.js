document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("loginForm");
  const emailInput = document.getElementById("loginEmail");
  const passwordInput = document.getElementById("loginPassword");

  if (!form) {
    console.error("❌ loginForm not found in HTML");
    return;
  }

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    let email = emailInput.value.trim();
    let password = passwordInput.value.trim();

    if (!email || !password) {
      alert("⚠️ Please enter both email and password");
      return;
    }

    // Local Storage se users fetch karo
    let users = JSON.parse(localStorage.getItem("users")) || [];

    // check exact match
    let existingUser = users.find(
      (u) => u.email === email && u.password === password
    );

    if (existingUser) {
      alert("✅ Login Successful! Welcome " + existingUser.firstName);
      window.location.href = "loader.html";
    } else {
      // check agar email exist karta hai lekin password galat hai
      let userByEmail = users.find((u) => u.email === email);
      if (userByEmail) {
        alert("❌ Invalid Password. Please try again.");
      } else {
        alert("⚠️ This email is not registered. Please register first.");
        if (confirm("Go to Register page?")) {
          window.location.href = "Register.html";
        }
      }
    }
  });
});